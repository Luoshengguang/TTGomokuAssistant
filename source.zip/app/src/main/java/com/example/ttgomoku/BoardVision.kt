package com.example.ttgomoku

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Provisional fixed-layout detector. Grid coordinates are ratios calibrated from
 * the single user-provided screenshot, not universal screen coordinates.
 */
object BoardVision {
    data class Detection(val board: Array<IntArray>, val occupied: Int, val confidence: Float, val message: String)

    fun detect(src: Bitmap): Detection {
        val w=src.width; val h=src.height
        val x0=w*0.075f; val x1=w*0.926f
        val y0=h*0.289f; val y1=h*0.677f
        val board=Array(12){IntArray(12)}
        var black=0; var white=0; var suspicious=0
        for(r in 0 until 12) for(c in 0 until 12) {
            val x=(x0+(x1-x0)*c/11f).toInt().coerceIn(3,w-4)
            val y=(y0+(y1-y0)*r/11f).toInt().coerceIn(3,h-4)
            val center=src.getPixel(x,y)
            val rr=(center shr 16) and 255
            val gg=(center shr 8) and 255
            val bb=center and 255
            val lum=(rr*299+gg*587+bb*114)/1000
            val spread=max(rr,max(gg,bb))-min(rr,min(gg,bb))
            // Check several near-center pixels; a single grid line is not a stone.
            var dark=0; var pale=0
            for(dx in intArrayOf(-2,0,2)) for(dy in intArrayOf(-2,0,2)) {
                val px=src.getPixel(x+dx,y+dy)
                val r2=(px shr 16) and 255; val g2=(px shr 8) and 255; val b2=px and 255
                val l2=(r2*299+g2*587+b2*114)/1000
                val sp=max(r2,max(g2,b2))-min(r2,min(g2,b2))
                if(l2<72 && sp<85) dark++
                if(l2>218 && min(r2,min(g2,b2))>205 && sp<35) pale++
            }
            when {
                dark>=5 -> { board[r][c]=1; black++ }
                pale>=6 -> { board[r][c]=2; white++ }
                // A suspicious center is a strong saturated highlight; leave empty, don't guess.
                spread>100 && lum in 70..210 -> suspicious++
            }
        }
        val occupied=black+white
        val confidence=if(suspicious>22) 0.65f else 0.92f
        val msg=if(confidence<0.86f) "棋盘画面存在较多高亮/遮挡"
                else "识别到黑棋${black}颗、白棋${white}颗"
        return Detection(board,occupied,confidence,msg)
    }
}
