package com.example.ttgomoku

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object { @Volatile var updater: ((String) -> Unit)? = null }
    private var wm: WindowManager? = null
    private var panel: LinearLayout? = null
    private var label: TextView? = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18,14,18,14)
            setBackgroundColor(0xe6172545.toInt())
        }
        label = TextView(this).apply {
            text = "五子棋助手\n等待屏幕识别授权…"
            textSize = 13f; setTextColor(0xffffffff.toInt())
        }
        panel!!.addView(label)
        updater = { value -> label?.post { label?.text = value } }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        wm?.addView(panel, p)
    }
    override fun onDestroy() {
        updater = null
        panel?.let { wm?.removeView(it) }
        panel = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
