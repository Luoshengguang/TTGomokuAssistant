package com.example.ttgomoku

import android.app.*
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.nio.ByteBuffer

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastRun = 0L
    private var myColor = 1

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val legacyData = intent?.getParcelableExtra<Intent>("data")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else legacyData
        if (code != Activity.RESULT_OK || data == null) {
            OverlayService.updater?.invoke("未取得录屏授权"); stopSelf(); return START_NOT_STICKY
        }
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        myColor = intent?.getIntExtra("myColor", 1)?.coerceIn(1, 2) ?: 1
        projection = mgr.getMediaProjection(code, data)
        startCapture()
        return START_STICKY
    }

    private fun createNotification() {
        val channel = "gomoku_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(channel, "五子棋屏幕识别", NotificationManager.IMPORTANCE_LOW))
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("TT五子棋助手正在识别")
                .setContentText("屏幕画面仅用于本地棋盘分析").setSmallIcon(android.R.drawable.ic_menu_search).build()
        else Notification.Builder(this).setContentTitle("TT五子棋助手正在识别").setSmallIcon(android.R.drawable.ic_menu_search).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(7, n)
        }
    }

    private fun startCapture() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val w=metrics.widthPixels; val h=metrics.heightPixels; val density=metrics.densityDpi
        thread=HandlerThread("gomoku-frame").also { it.start() }; handler=Handler(thread!!.looper)
        reader=ImageReader.newInstance(w,h,android.graphics.PixelFormat.RGBA_8888,2)
        reader!!.setOnImageAvailableListener({ ir ->
            val now=System.currentTimeMillis()
            if (now-lastRun < 650) { ir.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image=ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastRun=now
            try {
                val bitmap=imageToBitmap(image)
                val result=BoardVision.detect(bitmap)
                val text = if (result.confidence < 0.86f) {
                    "五子棋助手\n${result.message}\n请调整画面后重试"
                } else if (result.occupied < 2) {
                    "五子棋助手\n${result.message}\n等待更多棋子"
                } else {
                    val moves = GomokuEngine.recommend(result.board, myColor, 900)
                    if (moves.isEmpty()) "五子棋助手\n未找到合法落点"
                    else {
                        val colorName = if (myColor == 1) "黑" else "白"
                        val lines = moves.mapIndexed { index, move ->
                            val tag = if (index == 0) "⭐" else "${index + 1}."
                            "$tag ${move.row}行${move.col}列 · ${move.reason}"
                        }
                        "五子棋助手\n识别到${result.occupied}颗棋子\n本局执${colorName}棋（手动设置）\n" + lines.joinToString("\n")
                    }
                }
                OverlayService.updater?.invoke(text)
                bitmap.recycle()
            } catch (_: Exception) {
                OverlayService.updater?.invoke("五子棋助手\n画面读取失败，请重启识别")
            } finally { image.close() }
        },handler)
        // Android 14+ requires registering the callback before creating a virtual display.
        projection?.registerCallback(object: MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        },handler)
        display=projection?.createVirtualDisplay("GomokuCapture",w,h,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
        OverlayService.updater?.invoke("五子棋助手\n屏幕捕获已启动，正在定位棋盘…")
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane=image.planes[0]; val buffer=plane.buffer
        val pixelStride=plane.pixelStride; val rowStride=plane.rowStride
        val rowPadding=rowStride-pixelStride*image.width
        val padded=Bitmap.createBitmap(image.width+rowPadding/pixelStride,image.height,Bitmap.Config.ARGB_8888)
        buffer.rewind(); padded.copyPixelsFromBuffer(buffer)
        val cropped=Bitmap.createBitmap(padded,0,0,image.width,image.height)
        padded.recycle()
        return cropped
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
