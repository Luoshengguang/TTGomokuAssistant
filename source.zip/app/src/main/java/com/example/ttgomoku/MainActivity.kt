package com.example.ttgomoku

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestCapture = 9001
    private var myColor = 1 // 1 black, 2 white; choose each match because side can vary.
    private lateinit var colorLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,40,28,24) }
        box.addView(TextView(this).apply {
            text = "TT 五子棋助手\n开始对局前选择本局执子颜色。"
            textSize = 18f
        })
        colorLabel = TextView(this).apply { textSize = 16f; setPadding(0,20,0,12) }
        refreshColorLabel()
        box.addView(colorLabel)
        box.addView(Button(this).apply {
            text = "本局我是黑棋"
            setOnClickListener { myColor = 1; refreshColorLabel() }
        })
        box.addView(Button(this).apply {
            text = "本局我是白棋"
            setOnClickListener { myColor = 2; refreshColorLabel() }
        })
        box.addView(Button(this).apply {
            text = "授权悬浮窗"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else startService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        box.addView(Button(this).apply {
            text = "开始屏幕识别与分析"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
                }
            }
        })
        box.addView(Button(this).apply {
            text = "停止识别"
            setOnClickListener { stopService(Intent(this@MainActivity, ScreenCaptureService::class.java)) }
        })
        setContentView(box)
    }

    private fun refreshColorLabel() {
        colorLabel.text = "当前设置：本局执${if (myColor == 1) "黑" else "白"}棋（每局可更改）"
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
                putExtra("myColor", myColor)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
    }
}
