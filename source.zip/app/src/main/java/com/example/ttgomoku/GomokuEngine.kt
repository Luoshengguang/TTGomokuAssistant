package com.example.ttgomoku

/**
 * 12x12 Gomoku evaluator. Board values: 0 empty, 1 black, 2 white.
 * Returns only legal candidate points; candidate count is dynamic (1..3).
 */
object GomokuEngine {
    data class Move(val row: Int, val col: Int, val score: Int, val reason: String)
    private const val N = 12
    private val dirs = arrayOf(intArrayOf(1,0), intArrayOf(0,1), intArrayOf(1,1), intArrayOf(1,-1))

    fun recommend(board: Array<IntArray>, myColor: Int, maxMs: Long = 1200): List<Move> {
        require(board.size == N && board.all { it.size == N })
        require(myColor == 1 || myColor == 2)
        val opp = 3 - myColor
        val start = System.currentTimeMillis()
        val candidates = mutableListOf<Move>()
        // Restrict search to empty intersections near existing stones. On an empty
        // board, begin at the center instead of returning an arbitrary corner.
        val occupied = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until N) for (c in 0 until N) if (board[r][c] != 0) occupied += r to c
        val searchPoints = if (occupied.isEmpty()) {
            listOf((N / 2) to (N / 2))
        } else {
            buildList {
                for (r in 0 until N) for (c in 0 until N) {
                    if (board[r][c] == 0 && occupied.any { (sr, sc) -> kotlin.math.abs(sr-r) <= 2 && kotlin.math.abs(sc-c) <= 2 }) add(r to c)
                }
            }
        }
        searchPoints.forEach { (r, c) ->
            if (System.currentTimeMillis() - start > maxMs) return@forEach
            val win = makesFive(board, r, c, myColor)
            val block = makesFive(board, r, c, opp)
            val attack = patternScore(board, r, c, myColor)
            val defense = patternScore(board, r, c, opp)
            val score = when {
                win -> 10_000_000
                block -> 9_000_000
                else -> attack + (defense * 11 / 10)
            }
            val why = when {
                win -> "立即获胜"
                block -> "阻止对方立即获胜"
                defense >= 100_000 -> "优先防守"
                attack >= 100_000 -> "强力进攻"
                else -> "综合攻防"
            }
            candidates += Move(r + 1, c + 1, score, why)
        }
        if (candidates.isEmpty()) return emptyList()
        val sorted = candidates.sortedByDescending { it.score }
        val best = sorted.first()
        // If a forced win/block exists, never pad with unrelated alternatives.
        if (best.score >= 9_000_000) return listOf(best)
        val threshold = maxOf(1, best.score * 72 / 100)
        return sorted.filter { it.score >= threshold }.take(3)
    }

    private fun makesFive(b: Array<IntArray>, r: Int, c: Int, color: Int): Boolean {
        for (d in dirs) {
            var count = 1
            for (sign in intArrayOf(-1, 1)) {
                var rr = r + d[0] * sign; var cc = c + d[1] * sign
                while (rr in 0 until N && cc in 0 until N && b[rr][cc] == color) {
                    count++; rr += d[0] * sign; cc += d[1] * sign
                }
            }
            if (count >= 5) return true
        }
        return false
    }

    private fun patternScore(b: Array<IntArray>, r: Int, c: Int, color: Int): Int {
        var total = 0
        for (d in dirs) {
            var count = 1; var open = 0
            for (sign in intArrayOf(-1, 1)) {
                var rr = r + d[0] * sign; var cc = c + d[1] * sign
                while (rr in 0 until N && cc in 0 until N && b[rr][cc] == color) {
                    count++; rr += d[0] * sign; cc += d[1] * sign
                }
                if (rr in 0 until N && cc in 0 until N && b[rr][cc] == 0) open++
            }
            total += when {
                count >= 5 -> 1_000_000
                count == 4 && open == 2 -> 150_000
                count == 4 && open == 1 -> 60_000
                count == 3 && open == 2 -> 18_000
                count == 3 && open == 1 -> 3_000
                count == 2 && open == 2 -> 800
                count == 2 && open == 1 -> 120
                else -> count * 10
            }
        }
        return total
    }
}
