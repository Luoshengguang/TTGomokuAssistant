plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.ttgomoku"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.ttgomoku"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
    }
}
